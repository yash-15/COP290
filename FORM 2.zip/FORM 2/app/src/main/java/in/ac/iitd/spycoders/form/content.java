package in.ac.iitd.spycoders.form;

import android.os.Bundle;

/**
 * Created by sauhardgupta on 25/03/16.
 */
public class content extends pages {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.content_pages);

    }
}
